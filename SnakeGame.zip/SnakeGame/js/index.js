// Game Sound variables
const foodSound = new Audio('music/food.mp3');
const gameOverSound = new Audio('music/gameover.mp3');
const moveSound = new Audio('music/move.mp3');
const musicSound = new Audio('music/music.mp3');

// frtLogin
frtLogin = true;

// Game Logic variables
var speed = 10;
var frtScore = 0;
var sndScore = 0;
var lastPaintTime = 0;

// My code --- BLACKHOLE variables
var blackHoleEnergy, holeEnergyRecover, holePos, machineDirHole, holeRadius,
holeSizeDisplay, moveMin, moveMax;

// My code - FOOD variables
var foodEnergy, energyRecover, isMoving, food, machineDirFood;

// 1st PLAYER SNAKE
var frtSnakeArr, inputDirFrtSnake, frtDir;

// 2nd PLAYER SNAKE
var sndSnakeArr, inputDirSndSnake, sndDir;

/**
 * Function that handle the game logic when a player's snake eat the food:
 *      - Increase the body of the snake
 *      - Regenerate the food position
 *      - Increase the player's score
 * @param {*} snake 
 * @param {*} inputDirSnake 
 * @param {*} scoreBox 
 * @param {*} score 
 */
function ateFood(snake, inputDirSnake, scoreBox, score, isFrtPlayer) 
{
    let snakeTitle; // Used to identify which score belong to which player
    if(isFrtPlayer) {
        snakeTitle = "1st Player's score: ";
    }
    else {
        snakeTitle = "2nd Player's score: ";
    }
    if(snake[0].y === food.y && snake[0].x === food.x){
        foodSound.play();
        score += 1;
        scoreBox.innerHTML = snakeTitle + score;
        snake.unshift({x: snake[0].x + inputDirSnake.x, 
            y: snake[0].y + inputDirSnake.y});
        food = {x: Math.floor(Math.random() * 30), 
            y: Math.floor(Math.random() * 30)};
        // 
        holeSizeDisplay += 1;
        holeRadius += 0.3;
        moveMin += 1;
        moveMax -= 1;
        var r = document.querySelector(':root');
        r.style.setProperty('--width', holeSizeDisplay + 'vmin');
        r.style.setProperty('--height', holeSizeDisplay + 'vmin');
    }
}

/**
 * Funtion that initializes the initial parameters of all objects in game: 1st player's snake, 2nd player's snake, food and blackhole
 * @param NONE
 */
function reset()
{
    var r = document.querySelector(':root');
    r.style.setProperty('--width','4vmin');
    r.style.setProperty('--height', '4vmin');
    // My code --- BLACKHOLE variables
    // BlackHole Energy to move
    blackHoleEnergy = 2;
    holeEnergyRecover = 0;
    // BlackHole Position 
    holePos = {x: 5, y: 26}; // Initial position 
    machineDirHole = {x: 0, y:0}; // Store the changes in coordinate when the 
                                    // blackhole made a move.
    holeRadius = 3; //Blackhole radius
    holeSizeDisplay = 4;
    moveMin = 3;
    moveMax = 27;

    
    // My code - FOOD variables
    // Food Energy to move
    foodEnergy = 10;
    energyRecover = 0;
    isMoving = false;
    // Food Position
    food = {x: 16, y: 16}; // Initial position 
    machineDirFood = {x: 0, y:0}; // Store the changes in coordinate when the 
                                    // blackhole made a move.
    frtDir = "NONE"

    
    // 1st PLAYER SNAKE
    // Snake Position
    frtSnakeArr = [{x: 28, y: 28}]; // Initial position
    inputDirFrtSnake = {x: 0, y: 0}; // Store the changes in coordinate when the 
                                    // blackhole made a move.
    

    
    // 2st PLAYER SNAKE
    // Snake Position
    sndSnakeArr = [{x: 2, y: 2}]; // Initial position
    inputDirSndSnake = {x: 0, y: 0}; // Store the changes in coordinate when the 
                                    // blackhole made a move.
    sndDir = "NONE"
    
}

/**
 * Function to check whether the game is over or not.
 * 
 * Loss conditions:
 *      - The player's snake head bump into itself
 *      - The player's snake head bump into the map game board boundaries
 *      - The player's snake head bump into other snake's body\
 *      - The player's snake head bump into the black hole
 * @param {*} snake 
 * @returns true if the game is over and false otherwise
 */
function lossCheckForPlayer(frtSnake, sndSnake) { 
    // If player's snake hits the border
    if(frtSnake[0].x >= 30 || frtSnake[0].x <=0 || frtSnake[0].y >= 30 
        || frtSnake[0].y <=0){
        return true;
    }

    // If player's snake hits its body
    for (let i = 1; i < frtSnake.length; i++) {
        if(frtSnake[i].x === frtSnake[0].x && 
            frtSnake[i].y === frtSnake[0].y){
            return true;
        }
    }

    // If the player's snake hit other snake body
    for (let i = 1; i < sndSnake.length; i++) {
        if(sndSnake[i].x === frtSnake[0].x && 
            sndSnake[i].y === frtSnake[0].y){
            return true;
        }
    }

    // If player's snake is swallowed the black hole 
    if(Math.abs(holePos.x - frtSnake[0].x) < holeRadius && 
    Math.abs(holePos.y - frtSnake[0].y) < holeRadius)
    {
        return true;
    }
    return false;
}

/**
 * @author My code
 * Function that displays the first snake
 */
function frtSnakeDisplay() 
{
    frtSnakeArr.forEach((e, index)=>{
        snakeElement = document.createElement('div');
        snakeElement.style.gridRowStart = e.y;
        snakeElement.style.gridColumnStart = e.x;

        if(index === 0){ //The head
            snakeElement.classList.add('firstHead');
        }
        else{ //The body
            snakeElement.classList.add('firstBody');
        }
        board.appendChild(snakeElement);
    });
}

/**
 * @author My code
 * Function that helps player to move the snake
 */
 function frtSnakeMove()
 {
    if (frtDir == "LEFT")
    {
        inputDirFrtSnake.x = -1;
        inputDirFrtSnake.y = 0;
    } 
    if (frtDir == "UP")
    {
        inputDirFrtSnake.x = 0;
        inputDirFrtSnake.y = -1;
    }
    if (frtDir == "RIGHT")
    {
        inputDirFrtSnake.x = 1;
        inputDirFrtSnake.y = 0;
    }
    if (frtDir == "DOWN")
    {
        inputDirFrtSnake.x = 0;
        inputDirFrtSnake.y = 1;
    }
    // Moving the snake
    for (let i = frtSnakeArr.length - 2; i>=0; i--) { 
        frtSnakeArr[i+1] = {...frtSnakeArr[i]};
    }
    frtSnakeArr[0].x += inputDirFrtSnake.x;
    frtSnakeArr[0].y += inputDirFrtSnake.y;
}

/**
* @author My code
* Function that displays the second snake
*/
function sndSnakeDisplay() 
{
    sndSnakeArr.forEach((e, index)=>{
        sndSnakeElement = document.createElement('div');
        sndSnakeElement.style.gridRowStart = e.y;
        sndSnakeElement.style.gridColumnStart = e.x;

        if(index === 0){ //The head
            sndSnakeElement.classList.add('secondHead');
        }
        else{ //The body
            sndSnakeElement.classList.add('secondBody');
        }
        board.appendChild(sndSnakeElement);
    });
}

/**
 * @author My code
 * Function that helps player to move the snake
 */
function sndSnakeMove()
{
    if (sndDir == "LEFT")
    {
        inputDirSndSnake.x = -1;
        inputDirSndSnake.y = 0;
    } 
    if (sndDir == "UP")
    {
        inputDirSndSnake.x = 0;
        inputDirSndSnake.y = -1;
    }
    if (sndDir == "RIGHT")
    {
        inputDirSndSnake.x = 1;
        inputDirSndSnake.y = 0;
    }
    if (sndDir == "DOWN")
    {
        inputDirSndSnake.x = 0;
        inputDirSndSnake.y = 1;
    }
    // Moving the snake
    for (let i = sndSnakeArr.length - 2; i>=0; i--) { 
        sndSnakeArr[i+1] = {...sndSnakeArr[i]};
    }
    sndSnakeArr[0].x += inputDirSndSnake.x;
    sndSnakeArr[0].y += inputDirSndSnake.y;
}

/**
 * @author My code
 * Function that used to display the blackhole
 */
function blackHoleDisplay()
{
    holeElement = document.createElement('div');
    holeElement.style.gridRowStart = holePos.y;
    holeElement.style.gridColumnStart = holePos.x;
    holeElement.classList.add('blackHole');
    board.appendChild(holeElement);
}



/**
 * @author My code
 * Function to move the blackhole
 */
function blackHoleMove()
{
    
    blackHoleMoveLogic();
    holePos.x += machineDirHole.x;
    holePos.y += machineDirHole.y;
    
}

/**
 * @author My code
 * Function that defines the logic to move the blackhole
 */
function blackHoleMoveLogic()
{
    // Store all moves following this order: up, down, left, right
    let moves = [{x: 0, y: -1}, {x: 0, y: 1}, {x: -1, y: 0}, {x: 1, y: 0}];

    let possibleMoves = [];

    for (var n = 0; n < moves.length; n++) 
    {   
        let holeTemporary = {x: holePos.x, y: holePos.y};
        holeTemporary.x += moves[n].x;
        holeTemporary.y += moves[n].y;
        if(holeTemporary.x <= moveMax && holeTemporary.x >= moveMin && 
            holeTemporary.y <= moveMax && holeTemporary.y >= moveMin)
            {   
                possibleMoves.push(moves[n]);
            }
    }
    if(possibleMoves.length > 0) 
    {
        possibleMoves = possibleMoves.sort(() => Math.random() - 0.5);
        let i = Math.floor(Math.random() * (possibleMoves.length - 1));
        machineDirHole = possibleMoves[i];
    }
    else {
        machineDirHole = {x:0, y:0};
    }
}

/**
* @author My code
* Function that used to display the food with the protected shield
*/
function foodDisplay() 
{
    foodElement = document.createElement('div');
    foodElement.style.gridRowStart = food.y;
    foodElement.style.gridColumnStart = food.x;
    foodElement.classList.add('food')
    board.appendChild(foodElement);
 }
 
/**
 * @author My code
 * Function that used to display the food without the protected shield
 */
function foodWithoutShieldDisplay()
{
    foodElement = document.createElement('div');
    foodElement.style.gridRowStart = food.y;
    foodElement.style.gridColumnStart = food.x;
    foodElement.classList.add('foodWithoutShield')
    board.appendChild(foodElement);
}
 
/**
 * @author My code
 * Function that used to move the food when it has the protected shield
 */
 function foodMove() {
    bestMoveForFood();
    if(foodEnergy === 0) {
        isMoving = false;
        energyRecover += 1;
        preyEnergy.innerHTML = "Prey Energy: Recovering";
        if (energyRecover === 30) {
            foodEnergy = 10;
            energyRecover = 0;  
        }
    }
    if(foodEnergy != 0) 
    {
        foodEnergy -= 1;
        preyEnergy.innerHTML = "Prey Energy: " + foodEnergy + "/10";
        isMoving = true;
        food.x += machineDirFood.x;
        food.y += machineDirFood.y;
    }
}

/**
 * @author My code
 * Function that used to find the direction to move for the food
 * A direction is considerred "best" when after moving, the food's new location 
 * is at least 3 grids away from the snake.
 */
function bestMoveForFood() {
    // Store all moves following this order: up, down, left, right
    let moves = [{x: 0, y: -1}, {x: 0, y: 1}, {x: -1, y: 0}, {x: 1, y: 0}];

    let possibleMoves = [];

    for (var n = 0; n < moves.length; n++) 
    {   
        let foodTemporary = {x: food.x, y: food.y};
        foodTemporary.x += moves[n].x;
        foodTemporary.y += moves[n].y;
        if(foodTemporary.x <= 30 && foodTemporary.x >= 0 && 
            foodTemporary.y <= 30 && foodTemporary.y >= 0)
            {
                frtXDistance = Math.abs(foodTemporary.x - frtSnakeArr[0].x);
                frtYDistance = Math.abs(foodTemporary.y - frtSnakeArr[0].y);
                sndXDistance = Math.abs(foodTemporary.x - sndSnakeArr[0].x);
                sndYDistance = Math.abs(foodTemporary.y - sndSnakeArr[0].y);
                if((frtXDistance > 3 || frtYDistance > 3) && 
                (sndXDistance > 3 || sndYDistance > 3)) 
                {
                    possibleMoves.push(moves[n]);
                }
            }
    }
    if(possibleMoves.length > 0) 
    {
        possibleMoves = possibleMoves.sort(() => Math.random() - 0.5);
        let i = Math.floor(Math.random() * (possibleMoves.length - 1));
        machineDirFood = possibleMoves[i];
    }
    else 
    {
        machineDirFood = {x: 0, y: 0};
    }
}

/**
 * @author Source Code
 * Function that change game speed by changing the rendering time 
 */
function main(ctime) {
    window.requestAnimationFrame(main);
    if((ctime - lastPaintTime)/1000 < 1/speed){
        return;
    }
    lastPaintTime = ctime;
    gameEngine();
}

/**
 * 
 */
function gameEngine(){
    
    if(frtLogin)
    {
        reset();
        frtLogin = false;
    }

    // Check if the two player snake's heads bump into each other => both loss
    if (frtSnakeArr[0].x === sndSnakeArr[0].x &&
        frtSnakeArr[0].y === sndSnakeArr[0].y) 
    {
        gameOverSound.play();
        musicSound.pause();
        // show alert
        alert("It seems we have two losers here. Press any key to play again Kiddos!");
        reset();
        
        musicSound.play();
    }

    // Check if the first player loss
    if (lossCheckForPlayer(frtSnakeArr, sndSnakeArr)){
        gameOverSound.play();
        musicSound.pause();
        alert("Second player win. Press any key to play again Kiddo!");
        reset();  
        musicSound.play();
    }
    

    // Check if the second player loss
    if(lossCheckForPlayer(sndSnakeArr, frtSnakeArr)){
        gameOverSound.play();
        musicSound.pause();
        reset(); 
        alert("First player win. Press any key to play again Kiddo!");
        musicSound.play();  
    }
    
    // Check if the player's snake ate the food => increase the snake body, score
    // Increase the size of the black hole and re-generate the food
    ateFood(frtSnakeArr, inputDirFrtSnake, frtScoreBox, frtScore, true);
    ateFood(sndSnakeArr, inputDirSndSnake, sndScoreBox, sndScore, false);

    // Move the blackhole
    blackHoleMove();
    // Move the food
    foodMove();

    frtSnakeMove();
    console.log(inputDirFrtSnake);
    sndSnakeMove();
    
    // Clear the game board by deleting all the content of the element board
    board.innerHTML = "";
    // Display
    blackHoleDisplay();
    frtSnakeDisplay();
    sndSnakeDisplay();
    if(isMoving) {
        foodDisplay();
    }
    else{
        foodWithoutShieldDisplay();
    }
}




/**
 * Funtion that handle users' keyboard inputs to move their snake
 * @param {*} event 
 */
function Direction(event) {
    if (event.key == "a" && sndDir != "RIGHT" && sndDir != "LEFT") {
        moveSound.play();
        sndDir = "LEFT";
    } if (event.key == "w" && sndDir != "DOWN" && sndDir != "UP") {
        moveSound.play();
        sndDir = "UP";
    } if (event.key == "d" && sndDir != "LEFT" && sndDir != "RIGHT") {
        moveSound.play();
        sndDir = "RIGHT";
    } if (event.key == "s" && sndDir != "UP" && sndDir != "DOWN") {
        moveSound.play();
        sndDir = "DOWN";
    }
    if (event.key == "ArrowLeft" && frtDir != "RIGHT" && frtDir != "LEFT") {
        moveSound.play();
        frtDir = "LEFT";
    } if (event.key == "ArrowUp" && frtDir != "DOWN" && frtDir != "UP") {
        moveSound.play();
        frtDir = "UP";
    } if (event.key == "ArrowRight" && frtDir != "LEFT" && frtDir != "RIGHT") {
        moveSound.play();
        frtDir = "RIGHT";
    } if (event.key == "ArrowDown" && frtDir != "UP" && frtDir != "DOWN") {
        moveSound.play();
        frtDir = "DOWN";
    }
}


// Source code
window.requestAnimationFrame(main);
window.addEventListener('keydown', Direction);

   